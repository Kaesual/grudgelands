#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
game_dir="${1:-}"
[[ "$#" -eq 1 && -d "$game_dir/mods/MAPGEN/grug_mapgen/wp40" ]] || {
	echo "usage: patch_settlement_stages.sh DISPOSABLE_GAME_DIR" >&2
	exit 2
}
target="$game_dir/mods/MAPGEN/grug_mapgen/wp40/r6_settlement.lua"
patch_file="$script_dir/instrument-settlement-stages.patch"
[[ -f "$target" && -f "$patch_file" ]] || {
	echo "WP40 profile stages: settlement target or patch is absent" >&2
	exit 2
}
if rg -q 'GRUG_WP40_PROFILE_STAGE' "$target"; then
	echo "WP40 profile stages: snapshot is already instrumented" >&2
	exit 2
fi
filtered_patch="$(mktemp /tmp/grudgelands-wp40-stage-patch.XXXXXXXX)"
trap 'rm -f -- "$filtered_patch"' EXIT
awk '
	/^@@ -1883,9 \+1909,23 @@$/ {skip = 1; next}
	/^@@ -1900,7 \+1940,13 @@$/ {skip = 1; next}
	/^@@ -2011,6 \+2057,12 @@$/ {skip = 0}
	!skip {print}
' "$patch_file" >"$filtered_patch"
patch --batch --forward --directory="$game_dir" --strip=1 <"$filtered_patch"
p8_output="$(mktemp /tmp/grudgelands-wp40-stage-p8.XXXXXXXX)"
trap 'rm -f -- "$filtered_patch" "$p8_output"' EXIT
awk '
	/profile_p8_sort_us = 0$/ {p8 = 1}
	p8 && /coordinate.x, coordinate.y, coordinate.z = x, y, z$/ {
		print
		match($0, /[^[:space:]]/); indent = substr($0, 1, RSTART - 1)
		print indent "profile_p8_digest10_calls ="
		print indent "\tprofile_p8_digest10_calls + 1"
		print indent "local digest_started"
		print indent "if profile_enabled and"
		print indent "\t\tprofile_p8_digest10_calls % 1024 == 0 then"
		print indent "\tdigest_started = core.get_us_time()"
		print indent "end"
		next
	}
	p8 && /cell_y, cell_z, host_name, tier, band, x, y, z\)$/ {
		print
		match($0, /[^[:space:]]/); indent = substr($0, 1, RSTART - 1)
		indent = substr(indent, 1, length(indent) - 1)
		print indent "if digest_started then"
		print indent "\tprofile_p8_digest10_sample_calls ="
		print indent "\t\tprofile_p8_digest10_sample_calls + 1"
		print indent "\tprofile_p8_digest10_sample_us ="
		print indent "\t\tprofile_p8_digest10_sample_us +"
		print indent "\t\tcore.get_us_time() - digest_started"
		print indent "end"
		next
	}
	p8 && /sort_prefix\(coordinate_scratch, eligible, helpers.coordinate_less\)$/ {
		match($0, /[^[:space:]]/); indent = substr($0, 1, RSTART - 1)
		print indent "local sort_started = profile_enabled and core.get_us_time()"
		print
		print indent "if sort_started then"
		print indent "\tprofile_p8_sort_calls = profile_p8_sort_calls + 1"
		print indent "\tprofile_p8_sort_us = profile_p8_sort_us +"
		print indent "\t\tcore.get_us_time() - sort_started"
		print indent "end"
		next
	}
	p8 && /-- P9 cultural output is visible only after P8/ {p8 = 0}
	{print}
' "$target" >"$p8_output"
mv "$p8_output" "$target"
chmod 0644 "$target"
rg -q 'GRUG_WP40_PROFILE_STAGE' "$target" || {
	echo "WP40 profile stages: instrumentation marker was not installed" >&2
	exit 1
}
