-- Engine-backed, read-only schematic source for the production R6 template
-- expander. Luanti owns MTS decoding in both main and mapgen environments.

return function(core_api, schematic_directory, gravewood_directory)
	if type(core_api) ~= "table" or type(core_api.read_schematic) ~= "function" or
			type(schematic_directory) ~= "string" or schematic_directory == "" then
		error("WP40 R7 template source: construction seam differs", 0)
	end
	local function normalize_size(value)
		if type(value) ~= "table" then
			error("WP40 R7 template source: engine size differs", 0)
		end
		local metatable = getmetatable(value)
		if metatable ~= nil and (type(vector) ~= "table" or
				metatable ~= vector.metatable) then
			error("WP40 R7 template source: engine size metatable differs", 0)
		end
		local count = 0
		for key in pairs(value) do
			if key ~= "x" and key ~= "y" and key ~= "z" then
				error("WP40 R7 template source: engine size field differs", 0)
			end
			count = count + 1
		end
		if count ~= 3 or rawget(value, "x") == nil or
				rawget(value, "y") == nil or rawget(value, "z") == nil then
			error("WP40 R7 template source: engine size fields differ", 0)
		end
		return {x = value.x, y = value.y, z = value.z}
	end
	local source = {}
	function source.read(filename)
		if type(filename) ~= "string" or filename == "" or
				filename:find("/", 1, true) or filename:find("\\", 1, true) or
				not filename:match("^[a-z0-9_]+%.mts$") then
			error("WP40 R7 template source: schematic name differs", 0)
		end
		local directory = schematic_directory
		if filename == "grug_gravewood_small.mts" or filename == "grug_gravewood_tall.mts" then
			if type(gravewood_directory) ~= "string" or gravewood_directory == "" then
				error("WP40 R7 template source: gravewood directory missing", 0)
			end
			directory = gravewood_directory
		end
		local value = core_api.read_schematic(directory .. "/" .. filename,
			{write_yslice_prob = "all"})
		if type(value) ~= "table" or type(value.data) ~= "table" then
			error("WP40 R7 template source: engine read failed", 0)
		end
		-- read_schematic pushes size through push_v3s16 in current Luanti, so
		-- normalize its builtin vector to the plain R6 template boundary.
		value.size = normalize_size(value.size)
		for index = 1, #value.data do
			local cell = value.data[index]
			if type(cell) ~= "table" then
				error("WP40 R7 template source: engine cell differs", 0)
			end
			-- The accepted MTS parser normalizes CONTENT_IGNORE placeholders to
			-- air. Keep that exact input vocabulary before R6 hashes templates.
			if cell.name == "ignore" then cell.name = "air" end
			if cell.force_place == nil then cell.force_place = false end
		end
		return value
	end
	return source
end
